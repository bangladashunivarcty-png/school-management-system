<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreSubjectRequest;
use App\Http\Requests\Admin\UpdateSubjectRequest;
use App\Models\School;
use App\Models\Subject;
use App\Services\ActivityLogService;
use App\Services\DateTimeFormatter;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class SubjectController extends Controller
{
    public function __construct(
        private DateTimeFormatter $dateTimeFormatter,
        private ActivityLogService $activityLog
    ) {}
    public function index(Request $request): JsonResponse
    {
        if (! $request->user()->hasPermission('view-academic-setup')) {
            abort(403, 'Unauthorized.');
        }

        $query = Subject::query();
        $query->when($request->filled('search'), function ($q) use ($request) {
            $search = $request->input('search');
            $q->where(function ($sub) use ($search) {
                $sub->where('name', 'like', "%{$search}%")
                    ->orWhere('code', 'like', "%{$search}%")
                    ->orWhere('short_name', 'like', "%{$search}%");
            });
        });
        $query->when(
            $request->filled('status') && in_array($request->input('status'), ['active', 'inactive', 'archived'], true),
            fn ($q) => $q->where('status', $request->input('status'))
        );
        $query->when(
            $request->filled('type') && in_array($request->input('type'), ['general', 'elective', 'practical'], true),
            fn ($q) => $q->where('type', $request->input('type'))
        );
        $subjects = $query->ordered()
            ->get()
            ->map(fn (Subject $s) => $this->subjectToArray($s));

        return response()->json($subjects);
    }

    public function store(StoreSubjectRequest $request): JsonResponse
    {
        $school = School::first();
        $subject = Subject::create(array_merge($request->validated(), [
            'school_id' => $school?->id,
        ]));
        $this->activityLog->log('subjects', 'create', Subject::class, $subject->id, "Subject created: {$subject->name}", [], $request);

        return response()->json([
            'message' => 'Subject created.',
            'subject' => $this->subjectToArray($subject),
        ], 201);
    }

    public function show(Request $request, Subject $subject): JsonResponse
    {
        if (! $request->user()->hasPermission('view-academic-setup')) {
            abort(403, 'Unauthorized.');
        }

        return response()->json($this->subjectToArray($subject));
    }

    public function update(UpdateSubjectRequest $request, Subject $subject): JsonResponse
    {
        $subject->update($request->validated());
        $this->activityLog->log('subjects', 'update', Subject::class, $subject->id, "Subject updated: {$subject->name}", [], $request);

        return response()->json([
            'message' => 'Subject updated.',
            'subject' => $this->subjectToArray($subject->fresh()),
        ]);
    }

    private function subjectToArray(Subject $s): array
    {
        return [
            'id' => $s->id,
            'name' => $s->name,
            'code' => $s->code,
            'short_name' => $s->short_name,
            'type' => $s->type,
            'is_optional' => $s->is_optional,
            'has_practical' => $s->has_practical,
            'full_marks' => $s->full_marks,
            'pass_marks' => $s->pass_marks,
            'description' => $s->description,
            'status' => $s->status,
            'created_at' => $s->created_at->toIso8601String(),
            'created_at_formatted' => $this->dateTimeFormatter->formatDateTime($s->created_at),
            'updated_at' => $s->updated_at->toIso8601String(),
            'updated_at_formatted' => $this->dateTimeFormatter->formatDateTime($s->updated_at),
        ];
    }
}
